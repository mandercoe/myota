jQuery(document).ready(function($) {
    $('.banner_img').each(function() {
        var imgSrc = $(this).find('img').attr('src');
        $(this).css('background-image', 'url(' + imgSrc + ')');
    });
    
    $('.mainmenu').addClass('js-enabled');
    $('.mainmenu .hs-menu-flow-horizontal').before('<a class="mobile-trigger"><i></i></a>');
    $('.mainmenu .hs-item-has-children > a').after('<span class="child-triggerm"><img class="mbl_submenu_icon" src="https://f.hubspotusercontent40.net/hubfs/20484691/Arrow%20SVG%20(1).svg"></span>');
    $('a.mobile-trigger').click(function() {
        $(this).next('.mainmenu .hs-menu-flow-horizontal').slideToggle(250);
        $('body').toggleClass('mobile-open');
        $('span.child-triggerm').removeClass('child-open');
        $('.hs-menu-children-wrapper').slideUp(250);
        return false;
     });

    $('.mainmenu span.child-triggerm').click(function() {
        $(this).parent().siblings('.hs-item-has-children').removeClass('submenu-open');
        $(this).parent().siblings('.hs-item-has-children').find('span.child-triggerm').removeClass('child-open');
        $(this).parent().siblings('.hs-item-has-children').find('.hs-menu-children-wrapper').slideUp(250);
        $(this).next('.hs-menu-children-wrapper').slideToggle(250);
        $(this).next('.hs-menu-children-wrapper').children('.hs-item-has-children').find('.hs-menu-children-wrapper').slideUp(250);
        $(this).next('.hs-menu-children-wrapper').children('.hs-item-has-children').find('span.child-triggerm').removeClass('child-open');
        $(this).toggleClass('child-open');
        $(this).parent().toggleClass('submenu-open');
        return false;
    });
    
    $('.operational_acc_text').hide();
    $('.operational_acc_title').click(function() {
        $('.operational_acc_title').not(this).removeClass('active');
        $(this).toggleClass('active');
        $('.operational_acc_text').not($(this).next()).slideUp(400);
        $(this).next().slideToggle(400);
    }).filter(':first').click();
    
    if ($('.animatedParent').length > 0) {
        $('.animatedParent').addClass('animateOnce');
    }
    
    $(window).scroll(function() {
        var fixedtop = $('.header_navigation');
        if ($(this).scrollTop() > 2) {
			fixedtop.addClass('fixed');
            $('.lp_hero_section').each(function() {
                var heroSrc = $(this).css('background-image');
                heroSrc = heroSrc.replace('url(','').replace(')','');
                $('.lp-video-body .header_navigation').css('background-image', 'url(' + heroSrc + ')');
            });
		} else { 
			fixedtop.removeClass('fixed');
            $('.lp-video-body .header_navigation').css('background-image','');
		}
    });
    
    $('.meeting_slider_raw_wrap').slick();
    
    $('.inner_hero_v2 .inner_hero_raw .btn_style1 a').click(function() { 
        var id = $(this).attr('href');
        $('html, body').animate({
            scrollTop: $(id).offset().top
        }, 1000);
        return false;
    });
    
    $('.faq_text').hide();
    $('.faq_title').click(function() {
        $('.faq_title').not(this).removeClass('active');
        $(this).toggleClass('active');
        $('.faq_text').not($(this).next()).slideUp(400);
        $(this).next().slideToggle(400);
    });
    
    $('.site_search_section').insertAfter('.blog_topic_box');
    $('.topic_ul_wrap').insertAfter('.blog_function_raw');
    
    $('.site_search_section').addClass('show');
    
    var postbody = $('.blog_body_area').outerHeight() + 150;
    $('.blog_inner_right_pattern').css('top',postbody);
    
    $('.blog_topic_box span').click(function(){
        $(this).parents('.blog_function_raw').next('.topic_ul_wrap').slideToggle();
    });
    
    setTimeout(function(){ 

        if ($(".related_posts").length < 1) {
            $('.blog_related_posts').hide();
        }
        
        if ($(".related_posts").length > 4) {
            $('.relatedposts_list').addClass('related_slider');   
            $('.blog_related_posts').addClass('slider_active');
        }  
        
        if ($(".related_posts").length == 2) {
            $('.relatedposts_list').addClass('two_post');
        } 

        if ($(".related_posts").length == 3) {
            $('.relatedposts_list').addClass('three_post');
        } 
        
        if ($(".related_posts").length == 4) {
            $('.relatedposts_list').addClass('four_post');
        } 

        if ($(".related_posts").length == 1) {
            $('.relatedposts_list').addClass('one_post');   
            $('.relatedposts_list').removeClass('three_post');
        }

        $('.topic_ul_wrap ul li.featured').remove();

        $('.related_slider').slick({
            infinite: true,
            spped:800,
            dots:false,
            arrows:true,
            slidesToShow: 4,
            slidesToScroll: 1,
            responsive: [
                { breakpoint: 1200, settings: { slidesToShow: 3, dots:true, arrows:false, slidesToScroll: 1, infinite: true } },
                { breakpoint: 1024, settings: { slidesToShow: 2, dots:true, arrows:false, slidesToScroll: 1 } },
                { breakpoint: 600, settings: { dots:true, arrows:false, slidesToShow: 1, slidesToScroll: 1 } }
            ]
        });

    }, 100);
    
    $('.resource_box_wrap').slick({
        infinite: true,
        spped:800,
        dots:false,
        arrows:true,
        slidesToShow: 2,
        slidesToScroll: 1,
        responsive: [
            { breakpoint: 1201, settings: { slidesToShow: 2, dots:true, arrows:false, slidesToScroll: 1 } },
            { breakpoint: 992, settings: { dots: true, arrows: false, slidesToShow: 1, slidesToScroll: 1 } }
        ]
    });
    
    $('.password_protect_text').insertAfter('.password_raw form input[type="password"]');
    
    /* Blog post Custom Search */
    $("#value").keyup(function(event) {
        console.log(event.keyCode);
        $('.search_not_found').hide();
        var filter = $(this).val(),
            count = 0;
        $('.blog_index__post').each(function() {
            if ($(this).find('.blog_index_post_title').text().search(new RegExp(filter, "i")) < 0) {
                $(this).hide(); 
            } else {
                $(this).show(); 
                count++;
            }
        });
        if(count == 0){
            $('.search_not_found').show();
        }
    });
    
    if (window.matchMedia("(min-width: 768px)").matches) {
        $('.process_section.imp_data_section .process_col:nth-child(n+8)').wrapAll('<div class="process_col_second_raw"></div>');
        $('.process_col_second_raw').insertAfter('.process_col:nth-child(5)');
    }
    
    if (window.matchMedia("(max-width: 767px)").matches) {
        
        $('.hero_section').removeClass('animatedParent animateOnce');
        $('.hero_imgbox').removeClass('animated delay-500');
        $('.process_wrap').removeClass('animatedParent animateOnce');
        $('.process_wrap').removeAttr('data-sequence');
        $('.process_col').removeClass('animated');
        $('.process_raw').removeClass('animated');
        
        $('.team_imgbox').removeAttr('data-src data-fancybox');
        
        $('.team_imgbox').click(function(){
            $(this).parents().siblings().find('.team_imgbox').removeClass('active');
            $(this).addClass('active');
        });
        
        $('.arrow_left').click(function(){
            console.log('click');
            $(this).parent().removeClass('active');
            return false
        });
        
        $('.top_nav .hs-menu-wrapper > ul > li').insertAfter('.mainmenu .hs-menu-wrapper > ul > li:last-child');
    }
    
//     if ($('.count_num').length > 0) {
//         $('.count_num h3').counterUp({
//             delay: 20,
//             time: 3000
//         });
//     }
});

jQuery(window).load(function() {
    if ($('.sameheight').length > 0) { 
        equalheight('.sameheight');
    }
    sameheight('.process_title');
    sameheight('.security_model_content');
    sameheight('.imp_data_section .process_title_text');
    sameheight('.resource_index_title');
    
    $(".team_contentbox").mCustomScrollbar({
        theme:"light-thick",
        scrollButtons:{ enable: 'true' }
    });
    
    var ll = new LazyLoad({
        elements_selector: ".lazy"
    });
    var ll1 = new LazyLoad({
        elements_selector: ".lazy-bg"
    });
    
});

jQuery(window).resize(function(){
    if ($('.sameheight').length > 0) { 
        equalheight('.sameheight');
    }
    sameheight('.process_title');
    sameheight('.security_model_content');
    sameheight('.imp_data_section .process_title_text');
    sameheight('.resource_index_title');
});


equalheight = function(container){

    var currentTallest = 0,
    currentRowStart = 0,
    rowDivs = new Array(),
    $el,
    topPosition = 0;
    $(container).each(function() {
    
        $el = $(this);
        $($el).height('auto')
        topPostion = $el.position().top;
    
        if (currentRowStart != topPostion) {
            for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
                rowDivs[currentDiv].outerHeight(currentTallest);
            }
            rowDivs.length = 0; // empty the array
            currentRowStart = topPostion;
            currentTallest = $el.outerHeight();
            rowDivs.push($el);
        } else {
            rowDivs.push($el);
            currentTallest = (currentTallest < $el.outerHeight()) ? ($el.outerHeight()) : (currentTallest);
        }
        
        for (currentDiv = 0 ; currentDiv < rowDivs.length ; currentDiv++) {
            rowDivs[currentDiv].height(currentTallest);
        }
    });
}

function sameheight(clsaaName) {
  var highest = null;
  var hi = 0;
  jQuery(clsaaName).each(function() {
    var h = jQuery(this).outerHeight();
    if (h > hi) {
      hi = h;
      highest = jQuery(this);
    }
  });
  jQuery(clsaaName).css('height', hi);
}