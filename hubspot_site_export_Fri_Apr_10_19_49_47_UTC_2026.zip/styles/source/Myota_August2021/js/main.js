(function () {

  $('.footer').after('<a id="back-to-top" href="#top"><svg class="mk-svg-icon" data-name="mk-icon-chevron-up" data-cacheid="icon-61119817943f2" style=" height:16px; width: 16px; " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1792 1792"><path d="M1683 1331l-166 165q-19 19-45 19t-45-19l-531-531-531 531q-19 19-45 19t-45-19l-166-165q-19-19-19-45.5t19-45.5l742-741q19-19 45-19t45 19l742 741q19 19 19 45.5t-19 45.5z"></path></svg></a>');
  //   $("#back-to-top").hide();

  $(window).scroll(function(){
    if ($(window).scrollTop()>100){
      $("#back-to-top").addClass('active');
    }
    else
    {
      $("#back-to-top").removeClass('active');
    }
  });

  $("#back-to-top").click(function(){
    $('body,html').animate({scrollTop:0},500);
    return false;
  });

  $('.mobile-mkhb-navigation .hs-menu-wrapper>ul>li.hs-item-has-children>a').after('<span class="child-trigger"><svg style="height:16px;width: 16px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M512 192l-96-96-160 160-160-160-96 96 256 255.999z"></path></svg></span>');

  $('.mkhb-navigation-resp__box').click(function () {
    $('body').toggleClass('mobile-open');
  });   

  $('.child-trigger').click(function() {
    $(this).parent().siblings('.hs-item-has-children').find('.child-trigger').removeClass('child-open');
    $(this).next('.hs-menu-children-wrapper').slideToggle(250);
    $(this).next('.hs-menu-children-wrapper').children('.hs-item-has-children').find('.hs-menu-children-wrapper').slideUp(250);
    $(this).next('.hs-menu-children-wrapper').children('.hs-item-has-children').find('.child-trigger').removeClass('child-open');
    $(this).toggleClass('child-open');

  });

  $('.blog-share-container').click(function () {
    $(this).toggleClass('social-open');
  });

  $('body').click(function () {
    $('.blog-share-container').removeClass('social-open');
  });

  $(".blog-share-container").click(function( event ) {
    event.stopPropagation();
  });


  if(window.location.href.indexOf("tag") > -1) {
    $('body').addClass('hs-blog-topic')  
  }

})();

$(document).ready(function () {
  if ((navigator.userAgent.indexOf("Opera") || navigator.userAgent.indexOf('OPR')) != -1) {
    $('body').addClass('opera');
  } else if (navigator.userAgent.indexOf("Chrome") != -1) {
    $('body').addClass('chrome');
  } else if (navigator.userAgent.indexOf("Safari") != -1) {
    $('body').addClass('safari');
  } else if (navigator.userAgent.indexOf("Firefox") != -1) {
    $('body').addClass('firefox');
  } else if ((navigator.userAgent.indexOf("MSIE") != -1) || (!!document.documentMode == true)) //IF IE > 10
  {
    $('body').addClass('IE');
  } else {
    $('body').addClass('unknown');
  }
});
