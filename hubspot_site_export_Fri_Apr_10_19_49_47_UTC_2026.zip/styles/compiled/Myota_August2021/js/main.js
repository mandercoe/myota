<html>
 <head></head>
 <body>
  $(".footer").after('
  <a id="back-to-top" href="../../../../index.html">
   <svg class="mk-svg-icon" data-name="mk-icon-chevron-up" data-cacheid="icon-61119817943f2" style=" height:16px; width: 16px; " xmlns="http://www.w3.org/2000/svg" viewbox="0 0 1792 1792">
    <path d="M1683 1331l-166 165q-19 19-45 19t-45-19l-531-531-531 531q-19 19-45 19t-45-19l-166-165q-19-19-19-45.5t19-45.5l742-741q19-19 45-19t45 19l742 741q19 19 19 45.5t-19 45.5z"></path>
   </svg></a>'),$(window).scroll((function(){$(window).scrollTop()&gt;100?$("#back-to-top").addClass("active"):$("#back-to-top").removeClass("active")})),$("#back-to-top").click((function(){return $("body,html").animate({scrollTop:0},500),!1})),$(".mobile-mkhb-navigation .hs-menu-wrapper&gt;ul&gt;li.hs-item-has-children&gt;a").after('
  <span class="child-trigger">
   <svg style="height:16px;width: 16px" xmlns="http://www.w3.org/2000/svg" viewbox="0 0 512 512">
    <path d="M512 192l-96-96-160 160-160-160-96 96 256 255.999z"></path>
   </svg></span>'),$(".mkhb-navigation-resp__box").click((function(){$("body").toggleClass("mobile-open")})),$(".child-trigger").click((function(){$(this).parent().siblings(".hs-item-has-children").find(".child-trigger").removeClass("child-open"),$(this).next(".hs-menu-children-wrapper").slideToggle(250),$(this).next(".hs-menu-children-wrapper").children(".hs-item-has-children").find(".hs-menu-children-wrapper").slideUp(250),$(this).next(".hs-menu-children-wrapper").children(".hs-item-has-children").find(".child-trigger").removeClass("child-open"),$(this).toggleClass("child-open")})),$(".blog-share-container").click((function(){$(this).toggleClass("social-open")})),$("body").click((function(){$(".blog-share-container").removeClass("social-open")})),$(".blog-share-container").click((function(event){event.stopPropagation()})),window.location.href.indexOf("tag")&gt;-1&amp;&amp;$("body").addClass("hs-blog-topic"),$(document).ready((function(){-1!=(navigator.userAgent.indexOf("Opera")||navigator.userAgent.indexOf("OPR"))?$("body").addClass("opera"):-1!=navigator.userAgent.indexOf("Chrome")?$("body").addClass("chrome"):-1!=navigator.userAgent.indexOf("Safari")?$("body").addClass("safari"):-1!=navigator.userAgent.indexOf("Firefox")?$("body").addClass("firefox"):-1!=navigator.userAgent.indexOf("MSIE")||1==!!document.documentMode?$("body").addClass("IE"):$("body").addClass("unknown")})); //# sourceURL=https://cdn2.hubspot.net/hub/20484691/hub_generated/template_assets/52554756985/1666962701050/Myota_August2021/js/main.js
 </body>
</html>